document.addEventListener('DOMContentLoaded', function() {
    var fechaBajaDocumento = document.getElementById('id_FECHA_BAJA_DOCUMENTO');
    if (fechaBajaDocumento) {
        fechaBajaDocumento.disabled = true;
    }
});

document.addEventListener('DOMContentLoaded', function() {
    var observacionesBaja = document.getElementById('id_OBSERVACIONES_BAJA');
    if (observacionesBaja) {
        observacionesBaja.disabled = true;
    }
})

document.addEventListener('DOMContentLoaded', function() {
    var documentoBaja = document.getElementById('id_DOCUMENTO_BAJA');
    if (documentoBaja) {
        documentoBaja.disabled = true;
    }
});

document.addEventListener('DOMContentLoaded', function() {
    var motivoBaja = document.getElementById('id_MOTIVO_BAJA');
    if (motivoBaja) {
        motivoBaja.disabled = true;
    }
});

document.addEventListener('DOMContentLoaded', function() {
    var fechaBajaDocumento = document.getElementById('id_FECHA_BAJA_DOCUMENTO');
    if (fechaBajaDocumento) {
        fechaBajaDocumento.disabled = true;
    }
});

document.addEventListener('DOMContentLoaded', function() {
    var observacionesBaja = document.getElementById('id_OBSERVACIONES_BAJA');
    if (observacionesBaja) {
        observacionesBaja.disabled = true;
    }
})

document.addEventListener('DOMContentLoaded', function() {
    var documentoBaja = document.getElementById('id_DOCUMENTO_BAJA');
    if (documentoBaja) {
        documentoBaja.disabled = true;
    }
});

document.addEventListener('DOMContentLoaded', function() {
    var fechaBajaLogica = document.getElementById('id_FECHA_BAJA_LOGICA');
    if (fechaBajaLogica) {
        fechaBajaLogica.disabled = true;
    }
});